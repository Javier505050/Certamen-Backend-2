from django.contrib import admin
from .models import Equipo
# Register your models here.

@admin.register(Equipo)
class EquipoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'especialidad','disponibilidad']
    list_filter = ['disponibilidad']
    search_fields = ['nombre','especialidad']
    ordering = ['disponibilidad', 'nombre']
    list_editable = ['disponibilidad']